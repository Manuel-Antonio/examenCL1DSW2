package ejercicio1;

public class Diagnostico implements Runnable {
    // Propiedades
    private int[] pacientes;
    private int[] resultados;

    public Diagnostico(int[] pacientes) {
        this.pacientes = pacientes.clone();
        this.resultados = new int[pacientes.length]; // Inicializa el arreglo resultados
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < pacientes.length; i++) {
                int glucosa = pacientes[i];
                if (glucosa < 99) {
                    resultados[i] = 0; // Clasificar como NORMAL
                } else if (glucosa >= 100 && glucosa <= 125) {
                    resultados[i] = 1; // Clasificar como PREDIABETES
                } else {
                    resultados[i] = 2; // Clasificar como DIABETES
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int[] getPacientes() {
        return pacientes;
    }

    public void setPacientes(int[] pacientes) {
        this.pacientes = pacientes.clone();
    }

    public int[] getResultados() {
        return resultados;
    }

    public void setResultados(int[] resultados) {
        this.resultados = resultados.clone();
    }
}

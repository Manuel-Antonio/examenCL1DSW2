package ejercicio1;
import java.util.Arrays;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		int[] glucosa1 = generarNivelesGlucosa(10);
        int[] glucosa2 = generarNivelesGlucosa(10);
        int[] glucosa3 = generarNivelesGlucosa(10);

        // Imprime los arreglos de glucosa1, glucosa2 y glucosa3
        System.out.println("***** Arreglos Random de glucosa para diagnostico");
        System.out.println("glucosa1: " + Arrays.toString(glucosa1));
        System.out.println("glucosa2: " + Arrays.toString(glucosa2));
        System.out.println("glucosa3: " + Arrays.toString(glucosa3));
        
        Diagnostico diagnostico1 = new Diagnostico(glucosa1);
        Diagnostico diagnostico2 = new Diagnostico(glucosa2);
        Diagnostico diagnostico3 = new Diagnostico(glucosa3);

        Thread hilo1 = new Thread(diagnostico1);
        Thread hilo2 = new Thread(diagnostico2);
        Thread hilo3 = new Thread(diagnostico3);

        hilo1.start();
        hilo2.start();
        hilo3.start();

        try {
            hilo1.join();
            hilo2.join();
            hilo3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("\n***** Diagnostico: Normal = 0; Prediabetes = 1, Diabetes = 2");
        System.out.println("glucosa1: " + Arrays.toString(diagnostico1.getResultados()));
        System.out.println("glucosa2: " + Arrays.toString(diagnostico2.getResultados()));
        System.out.println("glucosa3: " + Arrays.toString(diagnostico3.getResultados()));

        int[] resultadosFinales = new int[30];
        System.arraycopy(diagnostico1.getResultados(), 0, resultadosFinales, 0, 10);
        System.arraycopy(diagnostico2.getResultados(), 0, resultadosFinales, 10, 10);
        System.arraycopy(diagnostico3.getResultados(), 0, resultadosFinales, 20, 10);

        mostrarResultados(resultadosFinales);
	}
	
	public static int[] generarNivelesGlucosa(int tamanio) {
        int[] nivelesGlucosa = new int[tamanio];
        Random rand = new Random();

        for (int i = 0; i < tamanio; i++) {
            nivelesGlucosa[i] = rand.nextInt(250) + 1; // Genera un número aleatorio entre 1 y 250
        }

        return nivelesGlucosa;
    }

    public static void mostrarResultados(int[] resultados) {
        int normales = 0, prediabetes = 0, diabetes = 0;

        for (int resultado : resultados) {
            if (resultado == 0) {
                normales++;
            } else if (resultado == 1) {
                prediabetes++;
            } else {
                diabetes++;
            }
        }

        System.out.println("\n******* Clasificación de resultados: *******");
        System.out.println("Normal: " + (normales * 100.0 / resultados.length) + "%");
        System.out.println("Prediabetes: " + (prediabetes * 100.0 / resultados.length) + "%");
        System.out.println("Diabetes: " + (diabetes * 100.0 / resultados.length) + "%");
    }
	

}

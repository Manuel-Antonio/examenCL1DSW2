package ejercicio2;

import java.io.IOException;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		try {
			
			// ********* IMPORTANTE ********* 
			// Solo ejecute este Main y apareceran los archivos txt. 
			// OJO : Refrescar el proyecto para poder verlos
			
            CuentasReader cuentasReader = new CuentasReader();
            List<Cuenta> cuentas = cuentasReader.leerCuentasDesdeJSON("src/main/resources/cuentas.json");

            CuentasProcessor cuentasProcessor = new CuentasProcessor();
            cuentasProcessor.procesarCuentas(cuentas);
            
            // Verificar si los archivos se crearon correctamente
            System.out.println("Archivos de texto creados exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

}

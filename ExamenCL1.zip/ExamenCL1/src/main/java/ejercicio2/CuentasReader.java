package ejercicio2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CuentasReader {
	public List<Cuenta> leerCuentasDesdeJSON(String rutaArchivo) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode root = objectMapper.readTree(new File(rutaArchivo));
        List<Cuenta> cuentas = new ArrayList<>();

        for (JsonNode cuentaNode : root) {
            Cuenta cuenta = new Cuenta();
            cuenta.setEstado(cuentaNode.get("estado").asBoolean());
            cuenta.setNroCuenta(cuentaNode.get("nro_cuenta").asInt());
            cuenta.setSaldo(cuentaNode.get("saldo").asDouble());
            cuenta.setBanco(cuentaNode.get("banco").asText());
            cuentas.add(cuenta);
        }

        return cuentas;
    }
}

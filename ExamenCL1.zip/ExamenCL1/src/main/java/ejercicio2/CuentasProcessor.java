package ejercicio2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CuentasProcessor {
	public void procesarCuentas(List<Cuenta> cuentas) throws IOException {
        for (Cuenta cuenta : cuentas) {
            if (cuenta.isEstado()) {
                String archivoSalida = "cuenta_" + cuenta.getNroCuenta() + ".txt";
                FileWriter writer = new FileWriter(archivoSalida);

                if (cuenta.getSaldo() > 5000.00) {
                    writer.write("Banco de origen: " + cuenta.getBanco() + "\n");
                    writer.write("La cuenta con el nro de cuenta: " + cuenta.getNroCuenta() + " tiene un saldo de $" + cuenta.getSaldo() + "\n");
                    writer.write("Usted es apto a participar en el concurso de la SBS por 10000.00 soles.\n");
                    writer.write("Suerte!\n");
                } else {
                    writer.write("Banco de origen: " + cuenta.getBanco() + "\n");
                    writer.write("La cuenta con el nro de cuenta: " + cuenta.getNroCuenta() + " no tiene un saldo superior a 5000.00.\n");
                    writer.write("Lamentablemente no podrá acceder al concurso de la SBS por 10000.00 soles.\n");
                    writer.write("Gracias\n");
                }

                writer.close();
            }
        }
    }
}
